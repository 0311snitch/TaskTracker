class RegularTaskView:
    @staticmethod
    def create_format():
        print("Для создания задачи необходимо ввести команду в виде task add 'username' 'password' 'project name' 'column "
              "name' 'task name' 'description' 'first date' 'second date' 'step' 'tags' 'priority'")