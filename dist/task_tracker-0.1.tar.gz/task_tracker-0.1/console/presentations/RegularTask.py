class RegularTaskView:
    @staticmethod
    def create_format():
        print("To create a task, enter the command as a task add 'username' 'password' 'project name' "
              "'column name' 'task name' 'description' 'first date' 'second date' 'step' 'type_of_step' 'tags' 'priority'")
